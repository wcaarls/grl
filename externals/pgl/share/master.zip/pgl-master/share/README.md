# teapot.stl

https://commons.wikimedia.org/wiki/File:Utah_teapot_(solid).stl
Nik Clark
Creative Commons CC0 1.0 Universal Public Domain Dedication

# ceramic-tiles.ppm

https://www.publicdomainpictures.net/en/view-image.php?image=123662
Piotr Siedlecki
Creative Commons CC0 1.0 Universal Public Domain Dedication
