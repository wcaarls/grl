#include "yaml-cpp/null.h"

namespace YAML {
_Null Null;
}
